---
poster: https://m.media-amazon.com/images/M/MV5BMmNlYzRiNDctZWNhMi00MzI4LThkZTctMTUzMmZkMmFmNThmXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_SX300.jpg
imdbId: tt0062622
scoreImdb: 8.3
length: 149 min
Genre: Adventure, Sci-Fi
year: 1968
cast: Keir Dullea, Gary Lockwood, William Sylvester
director: Stanley Kubrick
Rating: 4
Watched: true
Location: A - 1
Borrowed:
---
# **_2001: A Space Odyssey_**

![Image|200](https://m.media-amazon.com/images/M/MV5BMmNlYzRiNDctZWNhMi00MzI4LThkZTctMTUzMmZkMmFmNThmXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_SX300.jpg)

---

### Movie Synopsis
After uncovering a mysterious artifact buried beneath the Lunar surface, a spacecraft is sent to Jupiter to find its origins - a spacecraft manned by two men and the supercomputer H.A.L. 9000.

---
### My Thoughts / Review
Delete this text and write your thoughts on the movie here. This is where you take note of things like how the movie made you feel, how satisfied you were with the plot, etc.

---
### Quotes
Here's some space to write quotes from the movie that were impactful to you. Did a character say something really cool? Did the story make a really interesting observation about something? Write it here!

---
### Notes
Short notes on things I want to remember and possibly search on.

---
### Links
- 
- 
- 
