# 🎬 **My Movie Dashboard - All Features**

```dataviewjs
(async () => {
  try {
    // ── 1) Config
    const AFTER_KEY_FOR_RATING = "director";
    const AFTER_KEY_FOR_WATCHED = "Rating";
    const MOVIES_PER_PAGE = 10;

    // ── 2) Helper: upsert a frontmatter key
    async function writeMovieField(path, key, value, afterKey = null) {
      const file = app.vault.getAbstractFileByPath(path);
      let content = await app.vault.read(file);
      const match = content.match(/^---\n([\s\S]*?)\n---/);
      if (!match) return;

      let fmLines = match[1].split("\n");
      const existing = fmLines.findIndex(l => new RegExp(`^${key}:`).test(l));
      if (existing !== -1) {
        if (value === null || value === "") {
          fmLines.splice(existing, 1);
        } else {
          fmLines[existing] = `${key}: ${value}`;
        }
      } else if (value !== null && value !== "") {
        let insertAt = fmLines.length;
        if (afterKey) {
          const idx = fmLines.findIndex(l => new RegExp(`^${afterKey}:`).test(l));
          if (idx >= 0) insertAt = idx + 1;
        }
        fmLines.splice(insertAt, 0, `${key}: ${value}`);
      }

      const newFM = `---\n${fmLines.join("\n")}\n---`;
      let body = content.slice(match[0].length).replace(/^\r?\n+/, "");
      await app.vault.modify(file, `${newFM}\n${body}`);
    }

    // ── 3) Lightbox overlay for posters
    if (!document.getElementById("dvjs-image-overlay")) {
      const ov = document.createElement("div");
      ov.id = "dvjs-image-overlay";
      Object.assign(ov.style, {
        position: "fixed", top: 0, left: 0,
        width: "100vw", height: "100vh",
        background: "rgba(0,0,0,0.85)",
        display: "none", alignItems: "center", justifyContent: "center",
        zIndex: 9999, cursor: "pointer"
      });
      const im = document.createElement("img");
      Object.assign(im.style, {
        maxWidth: "95%", maxHeight: "95%",
        borderRadius: "4px", boxShadow: "0 4px 12px rgba(0,0,0,0.5)",
        pointerEvents: "none"
      });
      ov.appendChild(im);
      ov.addEventListener("click", () => ov.style.display = "none");
      document.body.appendChild(ov);
    }
    const overlay = document.getElementById("dvjs-image-overlay");
    const showOverlay = src => {
      overlay.querySelector("img").src = src;
      overlay.style.display = "flex";
    };

    // ── 4) Styles
    document.getElementById("dvjs-movie-style")?.remove();
    const style = document.createElement("style");
    style.id = "dvjs-movie-style";
    style.textContent = `
      .dv-table[data-dv-movies] {
        width: 100%;
        border: none;
        border-collapse: collapse;
        table-layout: fixed;
        margin-top: 0 !important;
      }
      .theme-dark .dv-table.dataview.table-view-table[data-dv-movies] thead tr th {
        padding: 4px !important;
        border: none !important;
        border-bottom: 2px solid var(--text-faint) !important;
        vertical-align: top !important;
        text-align: left !important;
      }
      .theme-dark .dv-table[data-dv-movies] tbody tr td {
        padding: 6px 4px 4px 4px !important;
        border: none !important;
        vertical-align: top !important;
        text-align: left !important;
      }
      .dv-table[data-dv-movies] .poster-col {
        width: 120px;
      }
      .dv-table[data-dv-movies] img {
        width: 80px !important;
        height: auto;
        border-radius: 4px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        cursor: zoom-in;
      }
      .dv-table[data-dv-movies] input[type="checkbox"] {
        transform: scale(1.2);
        margin: 0;
      }
      .dv-table[data-dv-movies] .rating-stars {
        display: flex;
        align-items: center;
        justify-content: flex-start;
      }
      .dv-table[data-dv-movies] .rating-stars span {
        cursor: pointer;
        font-size: 16px;
        margin-right: 2px;
      }
      .dv-table[data-dv-movies] .rating-stars .filled {
        color: var(--text-normal);
      }
      .dv-table[data-dv-movies] .rating-stars .hollow {
        color: var(--text-muted);
      }
      .dv-table[data-dv-movies] .rating-stars:hover .hollow,
      .dv-table[data-dv-movies] .rating-stars:hover .filled {
        opacity: 0.7;
      }
      .dv-table[data-dv-movies] .pagination-controls {
        margin-top: 8px;
        display: flex;
        gap: 8px;
        align-items: center;
      }
      .dv-table[data-dv-movies] .pagination-controls button {
        padding: 4px 8px;
        border-radius: 4px;
        cursor: pointer;
      }
      .dv-table[data-dv-movies] .pagination-controls button:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }
      .theme-dark .unwatched-btn.active, .theme-dark .show-all-btn.active {
        background-color: var(--text-faint) !important;
        color: var(--background-primary) !important;
      }
      .unwatched-btn, .show-all-btn {
        width: 32px;
        text-align: center;
      }
      .table-holder {
		margin-top: 0 !important;
		padding-top: 0 !important;
	  }
    `;
    document.head.appendChild(style);

    // ── 5) Collect movies, genres, and decades
    const allMovies = dv.pages('"Movies"');
    const singleGenres = new Set();
    const singleDecades = new Set();
    // Debugging: Track decade distribution and invalid years
    const decadeCounts = {};
    const invalidYears = [];
    allMovies.forEach(m => {
      // Collect genres
      if (m.genre) {
        const genres = Array.isArray(m.genre) ? m.genre : [m.genre];
        genres.forEach(genre => {
          const splitGenres = genre.split(",").map(g => g.trim());
          splitGenres.forEach(g => singleGenres.add(g));
        });
      }
      // Collect decades
      if (m.year) {
        if (Number.isInteger(m.year)) {
          const decade = `${Math.floor(m.year / 10) * 10}s`;
          singleDecades.add(decade);
          decadeCounts[decade] = (decadeCounts[decade] || 0) + 1;
        } else {
          invalidYears.push({ title: m.file.name, year: m.year });
        }
      }
    });
    // Ensure 1930s through 2030s and TV Series are included
    const baseDecades = ["TV Series", "1930s", "1940s", "1950s", "1960s", "1970s", "1980s", "1990s", "2000s", "2010s", "2020s", "2030s"];
    baseDecades.forEach(decade => singleDecades.add(decade));
    const genres = ["All", ...Array.from(singleGenres).sort()];
    const decades = ["All", ...Array.from(singleDecades).sort()];
    console.log("Total movies:", allMovies.length);
    console.log("Decade distribution:", decadeCounts);
    console.log("TV Series or invalid years:", invalidYears);

    // ── 6) Build toolbar
    const root = dv.container;
    root.empty();
    const toolbar = root.createEl("table", {
      style: "width:100%; border-collapse:collapse; margin-bottom:12px;"
    });
    const row = toolbar.insertRow();

    // Genre filter
    const labelCell = row.insertCell();
    labelCell.textContent = "Filter by Genre:";
    labelCell.style.cssText = "font-size:18px; white-space:nowrap; padding-right:8px;";
    const selectCell = row.insertCell();
    const sel = selectCell.appendChild(document.createElement("select"));
    sel.style.cssText = "padding:4px 8px; border-radius:4px; margin-right:12px;";
    genres.forEach(g => {
      const opt = document.createElement("option");
      opt.value = g; opt.textContent = g;
      sel.appendChild(opt);
    });
    const savedGenre = localStorage.getItem("dvjs-genre") || "All";
    if (genres.includes(savedGenre)) sel.value = savedGenre;

    // Decade filter
    const decadeLabelCell = row.insertCell();
    decadeLabelCell.textContent = "Year:";
    decadeLabelCell.style.cssText = "font-size:18px; white-space:nowrap; padding-right:8px;";
    const decadeSelectCell = row.insertCell();
    const decadeSel = decadeSelectCell.appendChild(document.createElement("select"));
    decadeSel.style.cssText = "padding:4px 8px; border-radius:4px; margin-right:12px;";
    decades.forEach(d => {
      const opt = document.createElement("option");
      opt.value = d; opt.textContent = d;
      decadeSel.appendChild(opt);
    });
    const savedDecade = localStorage.getItem("dvjs-decade") || "All";
    if (decades.includes(savedDecade)) decadeSel.value = savedDecade;
    else decadeSel.value = "All";

    // View toggle (Director/Actor(s))
    const viewLabelCell = row.insertCell();
    viewLabelCell.textContent = "View:";
    viewLabelCell.style.cssText = "font-size:18px; white-space:nowrap; padding-right:8px;";
    const viewSelectCell = row.insertCell();
    const viewSel = viewSelectCell.appendChild(document.createElement("select"));
    viewSel.style.cssText = "padding:4px 8px; border-radius:4px; margin-right:12px;";
    ["Director", "Actor(s)"].forEach(v => {
      const opt = document.createElement("option");
      opt.value = v; opt.textContent = v;
      viewSel.appendChild(opt);
    });
    const savedView = localStorage.getItem("dvjs-view") || "Actor(s)";
    viewSel.value = savedView;

    // Surprise Me!
    const surpriseCell = row.insertCell();
    const surpriseBtn = surpriseCell.appendChild(document.createElement("button"));
    surpriseBtn.textContent = "🎲 Surprise Me!";
    surpriseBtn.style.cssText = "padding:4px 8px; border-radius:4px; cursor:pointer;";

    // Unwatched button
    const unwatchedCell = row.insertCell();
    const unwatchedBtn = unwatchedCell.appendChild(document.createElement("button"));
    unwatchedBtn.textContent = "👁️";
    unwatchedBtn.title = "Toggle Show Unwatched Movies";
    unwatchedBtn.style.cssText = "padding:4px 8px; border-radius:4px; cursor:pointer; margin-left:8px;";
    unwatchedBtn.classList.add("unwatched-btn");
    let isUnwatched = localStorage.getItem("dvjs-unwatched") === "true";
    unwatchedBtn.classList.toggle("active", isUnwatched);

    // Show All button
    const showAllCell = row.insertCell();
    const showAllBtn = showAllCell.appendChild(document.createElement("button"));
    showAllBtn.textContent = "📜";
    showAllBtn.title = "Toggle Show All Movies";
    showAllBtn.style.cssText = "padding:4px 8px; border-radius:4px; cursor:pointer; margin-left:8px;";
    showAllBtn.classList.add("show-all-btn");
    let isShowAll = localStorage.getItem("dvjs-show-all") === "true";
    showAllBtn.classList.toggle("active", isShowAll);

    // Spacer & Search
    row.insertCell().style.width = "100%";
    const searchCell = row.insertCell();
    const searchInput = searchCell.appendChild(document.createElement("input"));
    searchInput.type = "text";
    searchInput.placeholder = "Search title or actor...";
    searchInput.style.cssText = "padding:4px 8px; border-radius:4px; width:150px;";
    const savedSearch = localStorage.getItem("dvjs-search") || "";
    searchInput.value = savedSearch;

    // Container for table and pagination
    const tableHolder = root.createDiv({ cls: "table-holder" });
    const paginationHolder = root.createDiv({ cls: "pagination-controls" });

    // ── 7) Render table
    function renderTable(list, viewMode = "Actor(s)", page = 1) {
      tableHolder.empty();
      paginationHolder.empty();

      // Pagination calculations (skipped if Show All)
      let pageMovies = list;
      let currentPage, totalPages;
      if (!isShowAll) {
        const totalMovies = list.length;
        totalPages = Math.max(1, Math.ceil(totalMovies / MOVIES_PER_PAGE));
        currentPage = Math.min(page, totalPages);
        const startIdx = (currentPage - 1) * MOVIES_PER_PAGE;
        const endIdx = startIdx + MOVIES_PER_PAGE;
        pageMovies = list.slice(startIdx, endIdx);
      }

      // Render table
      const tbl = tableHolder.createEl("table", {
        cls: "dv-table", attr: { "data-dv-movies": "" }
      });

      // Header row
      const thead = tbl.createEl("thead").createEl("tr");
      thead.createEl("th", {
        text: `Poster (${list.length})`,
        cls: "poster-col",
        style: "padding:4px;"
      });
      ["Title", "Year", viewMode, "Location ", "Genre", "Watched ", "Rating"].forEach(h =>
        thead.createEl("th", {
          text: h,
          style: "padding:4px;"
        })
      );

      // Body rows
      const tbody = tbl.createEl("tbody");
      pageMovies.forEach(m => {
        const path = m.file.path;
        const tr = tbody.createEl("tr");

        // Poster
        const pc = tr.createEl("td", { cls: "poster-col" });
        if (m.poster) {
          const img = pc.createEl("img", { attr: { src: m.poster } });
          img.addEventListener("mousedown", e => {
            e.preventDefault();
            showOverlay(m.poster);
          });
        }

        // Title, Year, Director or Actor(s), Location, Genre
        tr.createEl("td").createEl("a", {
          text: m.file.name,
          cls: "internal-link",
          attr: { "data-href": path }
        });
        tr.createEl("td", { text: m.year?.toString() || "" });
        tr.createEl("td", { text: viewMode === "Director" ? (m.director || "") : (m.cast || "") });
        tr.createEl("td", { text: m.Location || "" });
        tr.createEl("td", {
          text: Array.isArray(m.genre) ? m.genre.join(", ") : m.genre || ""
        });

        // Watched checkbox
        const wc = tr.createEl("td");
        const cb = wc.createEl("input", { attr: { type: "checkbox" } });
        cb.checked = Boolean(m.Watched);
        cb.addEventListener("change", async () => {
          await writeMovieField(path, "Watched", cb.checked, AFTER_KEY_FOR_WATCHED);
          const movieIdx = filteredMovies.findIndex(m => m.file.path === path);
          if (movieIdx !== -1) {
            filteredMovies[movieIdx] = { ...filteredMovies[movieIdx], Watched: cb.checked };
          }
          if (isUnwatched && cb.checked) {
            filteredMovies = filteredMovies.filter(movie => movie.file.path !== path);
          } else if (!cb.checked && isUnwatched) {
            const movie = allMovies.find(m => m.file.path === path);
            if (movie && sel.value !== "All") {
              const genres = Array.isArray(movie.genre) ? movie.genre : [movie.genre];
              if (genres.some(genre => genre && genre.split(",").map(s => s.trim()).includes(sel.value))) {
                filteredMovies = [...filteredMovies, movie];
              }
            } else if (movie) {
              filteredMovies = [...filteredMovies, movie];
            }
          }
          const newTotalPages = isShowAll ? 1 : Math.max(1, Math.ceil(filteredMovies.length / MOVIES_PER_PAGE));
          const adjustedPage = isShowAll ? 1 : Math.min(currentPage, newTotalPages);
          localStorage.setItem("dvjs-page", adjustedPage);
          renderTable(filteredMovies, viewSel.value, adjustedPage);
        });

        // Rating stars
        const rc = tr.createEl("td", { cls: "rating-stars" });
        const init = Number(m.Rating) || 0;
        const starContainer = rc.createEl("span");
        for (let i = 1; i <= 5; i++) {
          const star = starContainer.createEl("span", {
            text: i <= init ? "★" : "☆",
            cls: i <= init ? "filled" : "hollow"
          });
          star.addEventListener("click", async () => {
            const newRating = (init === i && i === 1) ? 0 : i;
            await writeMovieField(path, "Rating", newRating, AFTER_KEY_FOR_RATING);
            const movieIdx = filteredMovies.findIndex(m => m.file.path === path);
            if (movieIdx !== -1) {
              filteredMovies[movieIdx] = { ...filteredMovies[movieIdx], Rating: newRating };
            }
            renderTable(filteredMovies, viewSel.value, currentPage);
          });
        }
      });

      // Pagination controls (only if not Show All)
      if (!isShowAll && list.length > MOVIES_PER_PAGE) {
        const prevBtn = paginationHolder.createEl("button", { text: "Previous" });
        prevBtn.disabled = currentPage === 1;
        const pageInfo = paginationHolder.createEl("span", {
          text: ` Page ${currentPage} of ${totalPages} `
        });
        const nextBtn = paginationHolder.createEl("button", { text: "Next" });
        nextBtn.disabled = currentPage === totalPages;

        prevBtn.addEventListener("click", () => {
          if (currentPage > 1) {
            localStorage.setItem("dvjs-page", currentPage - 1);
            renderTable(filteredMovies, viewSel.value, currentPage - 1);
          }
        });
        nextBtn.addEventListener("click", () => {
          if (currentPage < totalPages) {
            localStorage.setItem("dvjs-page", currentPage + 1);
            renderTable(filteredMovies, viewSel.value, currentPage + 1);
          }
        });
      }

      // Reinforce button states
      unwatchedBtn.classList.toggle("active", isUnwatched);
      showAllBtn.classList.toggle("active", isShowAll);
    }

    // ── 8) Centralized update function
    let filteredMovies = allMovies;
    let lastPage = Number(localStorage.getItem("dvjs-page") || 1);
    function updateTable() {
      let f = allMovies;
      // Apply genre filter
      if (sel.value !== "All") {
        f = f.filter(m => {
          const genres = Array.isArray(m.genre) ? m.genre : [m.genre];
          return genres.some(genre => genre && genre.split(",").map(s => s.trim()).includes(sel.value));
        });
      }
      // Apply decade filter
      if (decadeSel.value !== "All") {
        if (decadeSel.value === "TV Series") {
          f = f.filter(m => !m.year || !Number.isInteger(m.year));
        } else {
          const decadeNum = parseInt(decadeSel.value);
          f = f.filter(m => {
            if (!m.year || !Number.isInteger(m.year)) return false;
            const movieDecade = Math.floor(m.year / 10) * 10;
            return movieDecade === decadeNum;
          });
        }
      }
      // Apply unwatched filter
      if (isUnwatched) f = f.filter(m => !m.Watched);
      // Apply search filter
      if (searchInput.value) {
        const q = searchInput.value.toLowerCase();
        f = f.filter(m =>
          m.file.name.toLowerCase().includes(q) ||
          (m.cast && m.cast.toLowerCase().includes(q))
        );
      }
      filteredMovies = [...f];
      console.log("Filtered movies count:", filteredMovies.length);
      const totalPages = isShowAll ? 1 : Math.max(1, Math.ceil(filteredMovies.length / MOVIES_PER_PAGE));
      const currentPage = isShowAll ? 1 : Math.min(lastPage, totalPages);
      localStorage.setItem("dvjs-page", currentPage);
      renderTable(filteredMovies, viewSel.value, currentPage);
    }

    // ── 9) Bind controls with debounced search
    sel.addEventListener("change", () => {
      localStorage.setItem("dvjs-genre", sel.value);
      localStorage.setItem("dvjs-page", 1);
      lastPage = 1;
      updateTable();
    });
    decadeSel.addEventListener("change", () => {
      localStorage.setItem("dvjs-decade", decadeSel.value);
      localStorage.setItem("dvjs-page", 1);
      lastPage = 1;
      updateTable();
    });
    viewSel.addEventListener("change", () => {
      localStorage.setItem("dvjs-view", viewSel.value);
      updateTable();
    });
    unwatchedBtn.addEventListener("click", () => {
      isUnwatched = !isUnwatched;
      localStorage.setItem("dvjs-unwatched", isUnwatched);
      localStorage.setItem("dvjs-page", 1);
      lastPage = 1;
      unwatchedBtn.classList.toggle("active", isUnwatched);
      showAllBtn.classList.remove("active");
      isShowAll = false;
      localStorage.setItem("dvjs-show-all", isShowAll);
      updateTable();
    });
    showAllBtn.addEventListener("click", () => {
      isShowAll = !isShowAll;
      localStorage.setItem("dvjs-show-all", isShowAll);
      if (!isShowAll) {
        localStorage.setItem("dvjs-page", lastPage);
      } else {
        lastPage = Number(localStorage.getItem("dvjs-page") || 1);
        localStorage.setItem("dvjs-page", 1);
      }
      showAllBtn.classList.toggle("active", isShowAll);
      unwatchedBtn.classList.remove("active");
      isUnwatched = false;
      localStorage.setItem("dvjs-unwatched", isUnwatched);
      updateTable();
    });
    let searchTimeout;
    searchInput.addEventListener("input", () => {
      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(() => {
        localStorage.setItem("dvjs-search", searchInput.value);
        localStorage.setItem("dvjs-page", 1);
        lastPage = 1;
        updateTable();
      }, 300);
    });
    surpriseBtn.addEventListener("click", () => {
      const pool = filteredMovies;
      if (!pool.length) return alert("No movies match the current filters!");
      const pick = pool[Math.floor(Math.random() * pool.length)];
      app.workspace.openLinkText(pick.file.path, "", true);
    });

    // Initial render
    updateTable();

  } catch (err) {
    dv.paragraph("**🛑 Error in movie dashboard:**");
    dv.codeblock(err.stack || err.toString(), "javascript");
    console.error(err);
  }
})();
```