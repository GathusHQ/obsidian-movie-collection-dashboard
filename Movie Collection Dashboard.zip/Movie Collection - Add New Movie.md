# 🎬 **Add New Movie**

```dataviewjs
try {
  const el = dv.el("div", "");
  el.innerHTML = `
    <style>
      .form-container { 
        max-width: 800px; 
        margin: 0 auto; 
        font-family: Arial, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; 
      }
      .form-grid { 
        display: grid; 
        grid-template-columns: 1fr 1fr; 
        gap: 20px; 
      }
      .form-group { 
        margin-bottom: 15px; 
      }
      .form-group label { 
        display: block; 
        font-weight: bold; 
        margin-bottom: 5px; 
      }
      .form-group input, 
      .form-group textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-family: Arial, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      }
      .checkbox-group { 
        margin-bottom: 20px; 
      }
      .checkbox-group h3 { 
        margin-bottom: 10px; 
      }
      .form-button {
        margin-right: 8px;
        padding: 8px 16px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 0.9em;
        font-family: inherit;
      }
      .error { 
        color: red; 
        font-weight: bold; 
        margin-top: 8px; 
      }
      .success {
        color: #2e7d32;
        font-weight: bold;
        font-size: 0.95em;
        margin-top: 16px;
        margin-bottom: 12px;
        padding: 8px 12px;
        background: rgba(46, 125, 50, 0.08);
        border-left: 4px solid #2e7d32;
        border-radius: 4px;
      }
    </style>
    <div class="form-container">
      <form id="movie-form">
        <div class="form-grid">
          <div class="form-group">
            <label for="title">Title</label>
            <input type="text" id="title" value="" required>
          </div>
          <div class="form-group">
            <label for="year">Year</label>
            <input type="number" id="year" value="" min="1900" max="2100">
          </div>
          <div class="form-group">
            <label for="director">Director</label>
            <input type="text" id="director" value="">
          </div>
          <div class="form-group">
            <label for="cast">Cast (comma-separated)</label>
            <input type="text" id="cast" value="">
          </div>
          <div class="form-group">
            <label for="poster">Poster Image URL</label>
            <input type="text" id="poster" value="" placeholder="https://example.com/image.jpg">
          </div>
          <div class="form-group">
            <label for="imdbId">IMDb ID (e.g., tt1234567)</label>
            <input type="text" id="imdbId" value="">
          </div>
          <div class="form-group">
            <label for="scoreImdb">IMDb Score (e.g., 7.5)</label>
            <input type="number" id="scoreImdb" step="0.1" min="0" max="10" value="">
          </div>
          <div class="form-group">
            <label for="length">Length (e.g., 120 min)</label>
            <input type="text" id="length" value="">
          </div>
          <div class="form-group">
            <label for="rating">Rating (0-5)</label>
            <input type="number" id="rating" min="0" max="5" value="">
          </div>
          <div class="form-group">
            <label for="location">Location (e.g., A - 1)</label>
            <input type="text" id="location" value="">
          </div>
          <div class="form-group">
            <label for="borrowed">Borrowed (e.g., Friend's Name)</label>
            <input type="text" id="borrowed" value="">
          </div>
        </div>
        <div class="checkbox-group">
          <h3>Watched?</h3>
          <label><input type="checkbox" id="watched"> Yes / No</label>
        </div>
        <div class="checkbox-group">
          <h3>Genres</h3>
          <label><input type="checkbox" id="genre-action"> Action</label><br>
          <label><input type="checkbox" id="genre-adventure"> Adventure</label><br>
          <label><input type="checkbox" id="genre-animation"> Animation</label><br>
          <label><input type="checkbox" id="genre-comedy"> Comedy</label><br>
          <label><input type="checkbox" id="genre-drama"> Drama</label><br>
          <label><input type="checkbox" id="genre-family"> Family</label><br>
          <label><input type="checkbox" id="genre-fantasy"> Fantasy</label><br>
          <label><input type="checkbox" id="genre-horror"> Horror</label><br>
          <label><input type="checkbox" id="genre-mystery"> Mystery</label><br>
          <label><input type="checkbox" id="genre-romance"> Romance</label><br>
          <label><input type="checkbox" id="genre-scifi"> Sci-Fi</label><br>
          <label><input type="checkbox" id="genre-thriller"> Thriller</label><br>
        </div>
        <div class="form-group">
          <label for="synopsis">Movie Synopsis</label>
          <textarea id="synopsis" rows="4"></textarea>
        </div>
        <div class="form-group">
          <label for="thoughts">My Thoughts / Review</label>
          <textarea id="thoughts" rows="4"></textarea>
        </div>
        <div class="form-group">
          <label for="quotes">Quotes</label>
          <textarea id="quotes" rows="4"></textarea>
        </div>
        <div class="form-group">
          <label for="notes">Notes</label>
          <textarea id="notes" rows="4"></textarea>
        </div>
        <div class="form-group">
          <label for="links">Links (one per line)</label>
          <textarea id="links" rows="4"></textarea>
        </div>
        <button type="submit" class="form-button">➕ Create Movie Page</button>
      </form>
      <div id="error-message" class="error"></div>
    </div>
  `;
  
  const form = el.querySelector("#movie-form");
  form.addEventListener("submit", async function(e) {
    e.preventDefault();
    try {
      // Collect form data
      const formData = {
        title: form.querySelector("#title").value.trim() || "Untitled",
        year: form.querySelector("#year").value || "",
        director: form.querySelector("#director").value.trim() || "",
        cast: form.querySelector("#cast").value.trim() || "",
        poster: form.querySelector("#poster").value.trim() || "",
        imdbId: form.querySelector("#imdbId").value.trim() || "",
        scoreImdb: form.querySelector("#scoreImdb").value || "",
        length: form.querySelector("#length").value.trim() || "",
        rating: form.querySelector("#rating").value || "",
        location: form.querySelector("#location").value.trim() || "",
        borrowed: form.querySelector("#borrowed").value.trim() || "",
        watched: form.querySelector("#watched").checked,
        synopsis: form.querySelector("#synopsis").value.trim() || "",
        thoughts: form.querySelector("#thoughts").value.trim() || "",
        quotes: form.querySelector("#quotes").value.trim() || "",
        notes: form.querySelector("#notes").value.trim() || "",
        links: form.querySelector("#links").value.trim().split("\n").filter(l => l.trim()).map(l => `- ${l.trim()}`) || [],
        genres: [
          { text: "Action", checked: form.querySelector("#genre-action").checked },
          { text: "Adventure", checked: form.querySelector("#genre-adventure").checked },
          { text: "Animation", checked: form.querySelector("#genre-animation").checked },
          { text: "Comedy", checked: form.querySelector("#genre-comedy").checked },
          { text: "Drama", checked: form.querySelector("#genre-drama").checked },
          { text: "Family", checked: form.querySelector("#genre-family").checked },
          { text: "Fantasy", checked: form.querySelector("#genre-fantasy").checked },
          { text: "Horror", checked: form.querySelector("#genre-horror").checked },
          { text: "Mystery", checked: form.querySelector("#genre-mystery").checked },
          { text: "Romance", checked: form.querySelector("#genre-romance").checked },
          { text: "Sci-Fi", checked: form.querySelector("#genre-scifi").checked },
          { text: "Thriller", checked: form.querySelector("#genre-thriller").checked }
        ].filter(g => g.checked).map(g => g.text)
      };

      // Validate poster URL
      if (formData.poster && !formData.poster.match(/\.(jpg|jpeg|png|gif)$/i)) {
        throw new Error("Poster Image URL must end with .jpg, .jpeg, .png, or .gif");
      }

      // Validate IMDb ID format
      if (formData.imdbId && !formData.imdbId.match(/^tt\d{7,8}$/)) {
        throw new Error("IMDb ID must be in the format 'tt' followed by 7 or 8 digits (e.g., tt1234567)");
      }

      // Sanitize title for filename
      const safeTitle = formData.title.replace(/[\[\]|]/g, '').replace(/[^a-zA-Z0-9\s]/g, '').replace(/\s+/g, ' ').trim();

      // Format genres for frontmatter (array syntax)
      const genreString = formData.genres.length > 0 ? `[${formData.genres.join(", ")}]` : "";

      // Build frontmatter
      const frontmatter = [
        `poster: ${formData.poster}`,
        `imdbId: ${formData.imdbId}`,
        `scoreImdb: ${formData.scoreImdb}`,
        `length: ${formData.length}`,
        `Genre: ${genreString}`,
        `year: ${formData.year}`,
        `cast: ${formData.cast}`,
        `director: ${formData.director}`,
        `Rating: ${formData.rating}`,
        `Watched: ${formData.watched}`,
        `Location: ${formData.location}`,
        `Borrowed: ${formData.borrowed}`
      ].filter(line => !line.endsWith(": ")).join("\n");

      // Build content
      const content = `---
${frontmatter}
---
# **_${formData.title}_**

![Image|200](${formData.poster})

---

### Movie Synopsis
${formData.synopsis || "Enter the movie synopsis here."}

---

### My Thoughts / Review
${formData.thoughts || "Delete this text and write your thoughts on the movie here. This is where you take note of things like how the movie made you feel, how satisfied you were with the plot, etc."}

---

### Quotes
${formData.quotes || "Here's some space to write quotes from the movie that were impactful to you. Did a character say something really cool? Did the story make a really interesting observation about something? Write it here!"}

---

### Notes
${formData.notes || "Short notes on things I want to remember and possibly search on."}

---

### Links
${formData.links.length > 0 ? formData.links.join("\n") : "- \n- \n- "}
`;

      // Create file in Movies folder
      const folder = "Movies";
      if (!app.vault.getAbstractFileByPath(folder)) {
        await app.vault.createFolder(folder);
      }
      const fileName = `${folder}/${safeTitle}.md`;

      // Check if file already exists
      if (app.vault.getAbstractFileByPath(fileName)) {
        throw new Error(`A movie page for "${formData.title}" already exists in the Movies folder.`);
      }

      // Create the file
      await app.vault.create(fileName, content);

      // Success message with class
      const successMsg = document.createElement("p");
      successMsg.textContent = `✅ Movie page created: [[${fileName}]]`;
      successMsg.className = "success";
      form.parentElement.appendChild(successMsg);

      // Reset the form (clears all fields and checkboxes)
      form.reset();

      // Auto-remove success message after 5 seconds
      setTimeout(() => {
        successMsg.remove();
      }, 5000);

    } catch (error) {
      const errorDiv = el.querySelector("#error-message");
      errorDiv.innerText = `Error creating movie page: ${error.message}`;
    }
  });
} catch (e) {
  dv.el("p", `Error loading form: ${e.message}`);
}
```